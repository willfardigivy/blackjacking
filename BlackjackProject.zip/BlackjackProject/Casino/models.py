from django.conf import settings
from django.db import models
from django.utils import timezone

class GameSession(models.Model):
    userChips = models.IntegerField(default=500)
    gamePhase = models.TextField(max_length=10,default="newgame")
    currentBet = models.IntegerField(default=0)

    def __str__(self):
        return self.gamePhase + ' ' + str(self.userChips)
    
    def doesUserHaveChips(self):
        if self.userChips > 0:
            return True
        else:
            return False

class DeckCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)

    def __str__(self):
        return self.card + ' of ' + self.suit
    
class PlayerCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)

    def __str__(self):
        return self.card + ' of ' + self.suit
    
class DealerCard(models.Model):
    card = models.CharField(max_length=2)
    suit = models.CharField(max_length=1)
    revealed = models.BooleanField(default=True)

    def __str__(self):
        return self.card + ' of ' + self.suit + ',' + str(self.revealed)

# python manage.py sqlmigrate Casino 000x
# python manage.py makemigrations
# python manage.py migrate