from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,HttpRequest
from .models import GameSession,DeckCard,PlayerCard,DealerCard
import random

# Create your views here.
def game(request):

    gameSession = GameSession.objects.all()[0]
    playerHand = PlayerCard.objects.all()
    dealerHand = DealerCard.objects.all()

    myDic = {
        'gameSession':gameSession,
        'playerHand':playerHand,
        'dealerHand':dealerHand,
        }
        
    return render(request, 'blackjack.html', context = myDic)

def newgame(request):

    # Wipe the old one!
    GameSession.objects.all().delete()
    DealerCard.objects.all().delete()
    PlayerCard.objects.all().delete()

    # Create new game session
    gameSession = GameSession()
    gameSession.gamePhase = 'betting'

    # New deck o'
    DeckCard.objects.all().delete()
    valueArray = ['A','2','3','4','5','6','7','8','9','10','J','Q','K']
    suitArray = ['H','S','C','D']

    for x in valueArray:
        for y in suitArray:
            cardy = DeckCard(card = x, suit = y)
            cardy.save()
    

    # Resave this stuff
    gameSession.save()

    return HttpResponseRedirect('/game')

def bet(request):

    # Get text from form
    gameSession = GameSession.objects.all()[0]
    gameSession.currentBet = int(request.POST.get('amount'))
    gameSession.gamePhase = 'playerturn'
    gameSession.save()

    # Give me the cards to start with
    hit('player')
    hit('dealer')
    hit('player')
    hit('dealer',False)

    return HttpResponseRedirect('/game/')

def hit(owner,revealed=True):
    deckSize = DeckCard.objects.all().count()
    cardIndex = random.randint(0,deckSize - 1)

    deckCard = DeckCard.objects.all()[cardIndex]
    print(deckCard.card + ' of ' + deckCard.suit + ' to ' + owner + ', revealed ' + str(revealed))

    if owner == 'dealer':
        dealerCard = DealerCard(card = DeckCard.card, suit = DeckCard.suit, revealed = revealed)
        dealerCard.save()
    elif owner =='player':
        playerCard = DealerCard(card = DeckCard.card, suit = DeckCard.suit)
        playerCard.save()

    DeckCard.objects.all()[cardIndex].delete()
    deckSize = DeckCard.objects.all().count()
    print('Cards left: ' + str(deckSize))

